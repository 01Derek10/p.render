<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LoginControlador extends Controller
{
    //
}
